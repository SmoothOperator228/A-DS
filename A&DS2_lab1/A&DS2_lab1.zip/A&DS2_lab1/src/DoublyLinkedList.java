public class DoublyLinkedList implements ListInterface{
    public class DoubleNode {
        private DoubleNode previous;
        private DoubleNode next;
        private Object obj;

        protected DoubleNode getPrevious() {
            return previous;
        }

        protected void setPrevious(DoubleNode previous) {
            this.previous = previous;
        }

        protected DoubleNode getNext() {
            return next;
        }

        protected void setNext(DoubleNode next) {
            this.next = next;
        }

        protected Object getObj() {
            return obj;
        }

        protected void setObj(Object obj) {
            this.obj = obj;
        }
    }

    private DoubleNode head;
    private DoubleNode tail;
    private int elements = 0;


    public DoubleNode getHead() {
        return head;
    }

    public DoubleNode getTail() {
        return tail;
    }

    public int getElements() {
        return elements;
    }

    public boolean isEmpty() {
        if (head == null || tail == null) {
            return true;
        }
        return false;
    }

    public void add(Object obj) {
        //додавання за замовчуванням = додавання останнього елемента (у хвіст)
        DoubleNode node = new DoubleNode();
        node.setObj(obj);
        if (!isEmpty()) {
            tail.setNext(node);
            node.setPrevious(tail);
        }
        tail = node;
        if (isEmpty()) {
            head = node;
        }
        elements++;
    }

    public void addHead(Object obj) {
        DoubleNode node = new DoubleNode();
        node.setObj(obj);

        if (!isEmpty()) {
            head = node;
            tail = node;
        } else {
            node.setNext(head);
            head.setPrevious(node);
            head = node;
        }
        elements++;
    }

    public void insert(Object obj, int index) {
        if (index < 0 || index > elements) {
            throw new IndexOutOfBoundsException("Індекс" + index + "виходить за межі списку");
        }
        if (isEmpty()) {
            throw new ObjectNotFoundException("Нема чого видаляти, список порожній");
        }
        if (index == 0) {
            addHead(obj);
        }
        if (index == elements) {
            add(obj);
        }
        DoubleNode currentNode = head;
        for (int i = 0; i < elements; i++) {
            if (i == 0) {
                currentNode = head;
            } else {
                currentNode = currentNode.next;
            }
            if (i == index - 1) {
                DoubleNode node = new DoubleNode();
                node.setObj(obj);
                node.setNext(currentNode);
                node.setPrevious(currentNode.getPrevious());
                currentNode.setPrevious(node);
                elements++;
                break;
            }
        }
    }

    public void removeTail() {
        if (isEmpty()) {
            throw new ObjectNotFoundException("Нема чого видаляти, список порожній");
        }
        tail = tail.getPrevious();
        tail.setNext(null);
        elements--;
    }

    public void removeHead() {
        if (isEmpty()) {
            throw new ObjectNotFoundException("Нема чого видаляти, список порожній");
        }
        head = head.getNext();
        head.setPrevious(null);
        elements--;
    }

    public void remove(int index) throws ObjectNotFoundException {
        if (index < 0 || index > elements - 1) {
            throw new IndexOutOfBoundsException("Індекс виходить за межі списку");
        }
        if (index == 0) {
            removeHead();
        }
        if (index == elements - 1) {
            removeTail();
        }

        DoubleNode currentNode = head;
        for (int i = 0; i < elements - 1; i++) {
            if (i == 0) {
                currentNode = head;
            } else {
                currentNode = currentNode.next;
            }
            if (i == index) {
                currentNode.getPrevious().setNext(currentNode.getNext());
                currentNode.getNext().setPrevious(currentNode.getPrevious());
                elements--;
                return;
            }

        }
    }

    public void replace(int index, Object obj) {
        if (index < 0 || index >= elements) {
            throw new IndexOutOfBoundsException("Індекс виходить за межі списку");
        }
        if (index == 0) {
            head.setObj(obj);
        }

        if (index == elements - 1) {
            tail.setObj(obj);
        }
        DoubleNode currentNode = head;
        for (int i = 0; i < elements - 1; i++) {
            if (i == 0) {
                currentNode = head;
            } else {
                currentNode = currentNode.next;
            }
            if (i == index) {
                currentNode.setObj(obj);
            }
        }
    }

    public void replace(Object changed, Object changer) {
        DoubleNode currentNode = head;
        for (int i = 0; i < elements; i++) {
            if (i == 0) {
                currentNode = head;
            } else {
                currentNode = currentNode.next;
            }
            if (currentNode.getObj().equals(changed)) {
                replace(i, changer);
                return;
            }
        }
        throw new ObjectNotFoundException("Об'єкту, який ви хочете замінити не знайдено.");
    }


}