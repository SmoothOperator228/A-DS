public class Entry {
    public static void main(String[] args){
        
    }
}
